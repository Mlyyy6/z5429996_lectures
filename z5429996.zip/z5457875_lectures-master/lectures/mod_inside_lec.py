""" mod_inside_lec.py

A module inside the `lectures` package
"""

print("You can see me!")