""" another_mod_inside_lec.py

Another module inside the `lectures` package
"""

import lectures.mod_inside_lec